## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = "hide"
)

## ----setup--------------------------------------------------------------------
library(GLMMs)
library(dplyr)
library(tidyverse)
library(lme4)
library(broom.mixed)

## -----------------------------------------------------------------------------
epilepsy <- readr::read_csv("epilepsy.csv")

epilepsy %>%
  mutate(treatment = ifelse(treat == 0, "Placebo", "Drug"), 
         period = ifelse(expind == 0, "before", "after")) %>%
  group_by(treatment, period) %>%
  mutate(seizures = mean(seizures)) %>%
  ggplot(aes(x = treatment, y = seizures, fill = period)) +
  geom_bar(stat = "identity", position = position_dodge()) +
  ggtitle("Average number of seizures before and after treatment")

## -----------------------------------------------------------------------------
epilepsy %>%
  group_by(id) %>%
  mutate(seizures = sum(seizures), 
         treatment = ifelse(treat == 0, "Placebo", "Drug")) %>%
  ggplot(aes(x = age, y = seizures, color = treatment)) +
  geom_point() +
  ggtitle("Relation between number of seizures and age")

## -----------------------------------------------------------------------------
## Example:

epilepsy <- epilepsy %>%
  group_by(id, treat, expind, age) %>%
  summarize(seizures = sum(seizures),
            .groups = "drop")

full_fit <- run_model(epilepsy,example = "epilepsy")
true_beta <- full_fit$beta
true_sigmasq <- full_fit$sigmasq

## Bootstrap process:
boot <- bootstrap(epilepsy, subject_index = 1, B = 100, true_beta, true_sigmasq)
## Summary of bootstrap:
BS_summary <- BootSummary(boot)


## -----------------------------------------------------------------------------
head(boot %>% select(-group))

## -----------------------------------------------------------------------------
boot %>%
  ggplot(aes(x = estimate)) +
  geom_density() +
  facet_wrap(~term) +
  ggtitle("Distribution of bootstrap estimators")

## -----------------------------------------------------------------------------
## hypothesis test
h0_beta <- true_beta
h0_beta[4] <- 0
boot_h0 <- bootstrap(dataset = epilepsy, h0_beta, true_sigmasq)

t_value <- full_fit$test_stat[4]
p_value <- (boot_h0 %>%
  filter(term == "expind:treat") %>%
  summarize(p = mean(abs(statistic) > abs(t_value))))$p

if(p_value < 0.05){
  print('Given 5% significance level, p value < 0.05 shows enough evidence against the null hypothesis.
        We reject H0, and beta is significantly different from 0')
} else{
  print('Given 5% significance level, p value > 0.05 does not show enough evidence against the null hypothesis.
        We do not reject H0, and beta is not significantly different from 0')
  }


